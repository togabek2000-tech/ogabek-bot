import asyncio
import logging
import sqlite3
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)

BOT_TOKEN = "ВАШ_ТОКЕН_ОТ_BOTFATHER"
ADMIN_ID = 51885488519
SUPPORT_CONTACT = "@dasturchi_HTML_CSS"

CARD_SBP_INFO = "СБП / Карта РФ: +7 (999) 000-00-00 (Т-Банк / Сбер)"
CLICK_UZUM_INFO = "Click / Uzum: 8600 0000 0000 0000 (Og'abek)"
CRYPTO_INFO = "USDT (TRC20): TYourAddressHere...\nTON: EQYourAddressHere..."

CATALOG = {
    "uc_60": {"name": "60 UC", "rub": 85, "uzs": 11900},
    "uc_120": {"name": "120 UC", "rub": 172, "uzs": 24100},
    "uc_180": {"name": "180 UC", "rub": 258, "uzs": 36100},
    "uc_325": {"name": "325 UC", "rub": 442, "uzs": 61900},
    "uc_385": {"name": "385 UC", "rub": 527, "uzs": 73800},
    "uc_660": {"name": "660 UC (RP)", "rub": 871, "uzs": 121900},
    "uc_720": {"name": "720 UC", "rub": 956, "uzs": 133800},
    "uc_985": {"name": "985 UC", "rub": 1310, "uzs": 183400},
    "uc_1320": {"name": "1320 UC", "rub": 1739, "uzs": 243500},
    "uc_1800": {"name": "1800 UC", "rub": 2189, "uzs": 306500},
    "uc_2125": {"name": "2125 UC", "rub": 2625, "uzs": 367500},
    "uc_3850": {"name": "3850 UC", "rub": 4339, "uzs": 607500},
    "uc_5650": {"name": "5650 UC", "rub": 6530, "uzs": 914200},
    "uc_8100": {"name": "8100 UC", "rub": 8689, "uzs": 1216500},
    "uc_16200": {"name": "16200 UC", "rub": 17289, "uzs": 2420000},
    "uc_32400": {"name": "32400 UC", "rub": 34489, "uzs": 4825000},
}

conn = sqlite3.connect("shop.db")
cur = conn.cursor()
cur.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        pack_name TEXT,
        player_id TEXT,
        amount_rub INTEGER,
        amount_uzs INTEGER,
        pay_method TEXT,
        status TEXT DEFAULT 'pending'
    )
''')
conn.commit()
conn.close()

class OrderState(StatesGroup):
    entering_pubg_id = State()
    choosing_method = State()
    waiting_receipt = State()

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
logging.basicConfig(level=logging.INFO)

def main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="💎 Купить UC"), KeyboardButton(text="📊 Прайс-лист")],
            [KeyboardButton(text="🆔 Инструкция по ID"), KeyboardButton(text="🆘 Поддержка")],
            [KeyboardButton(text="📦 Мои заказы")]
        ],
        resize_keyboard=True
    )

def catalog_markup():
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=f"{v['name']} — {v['rub']} ₽ / {v['uzs']} UZS", callback_data=f"buy_{k}")] for k, v in CATALOG.items()]
    )

def pay_markup():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🇷🇺 СБП / Карты РФ", callback_data="pay_sbp")],
            [InlineKeyboardButton(text="🇺🇿 Click / Uzum Bank / Payme", callback_data="pay_uz")],
            [InlineKeyboardButton(text="🪙 Криптовалюта (USDT / TON)", callback_data="pay_crypto")],
            [InlineKeyboardButton(text="❌ Отменить", callback_data="pay_cancel")]
        ]
    )

@dp.message(CommandStart())
async def start_handler(msg: Message, state: FSMContext):
    await state.clear()
    await msg.answer(
        f"👋 **Магазин Og'abek_UC**\n\n"
        f"⚡ Пополнение PUBG Mobile по Player ID.\n"
        f"💳 Оплата: СБП, Карты РФ, Click, Uzum и Крипта.\n"
        f"🆘 Поддержка: {SUPPORT_CONTACT}",
        reply_markup=main_menu(),
        parse_mode="Markdown"
    )

@dp.message(F.text == "📊 Прайс-лист")
async def price_handler(msg: Message):
    text = "📋 **Прайс-лист Og'abek_UC:**\n━━━━━━━━━━━━━━━━━━\n"
    for _, v in CATALOG.items():
        text += f"• **{v['name']}** — {v['rub']} ₽ ({v['uzs']} UZS)\n"
    text += f"━━━━━━━━━━━━━━━━━━\n🆘 Связь: {SUPPORT_CONTACT}"
    await msg.answer(text, parse_mode="Markdown")

@dp.message(F.text == "🆔 Инструкция по ID")
async def guide_handler(msg: Message):
    await msg.answer("📌 Откройте профиль в PUBG Mobile и скопируйте числовой ID под ником (например: `5182947261`).", parse_mode="Markdown")

@dp.message(F.text == "🆘 Поддержка")
async def support_handler(msg: Message):
    await msg.answer(f"👨‍💻 Поддержка: {SUPPORT_CONTACT}", parse_mode="Markdown")

@dp.message(F.text == "📦 Мои заказы")
async def orders_handler(msg: Message):
    c = sqlite3.connect("shop.db")
    r = c.cursor().execute("SELECT id, pack_name, player_id, amount_rub, status FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 5", (msg.from_user.id,)).fetchall()
    c.close()
    if not r:
        await msg.answer("У вас еще нет заказов.")
        return
    out = "📦 **Ваши заказы:**\n"
    for row in r:
        st = "🟢 Выдан" if row[4] == "done" else "🟡 Проверяется"
        out += f"• #{row[0]}: {row[1]} (ID: `{row[2]}`) — {row[3]} ₽ [{st}]\n"
    await msg.answer(out, parse_mode="Markdown")

@dp.message(F.text == "💎 Купить UC")
async def buy_handler(msg: Message):
    await msg.answer("Выберите нужный пак UC:", reply_markup=catalog_markup())

@dp.callback_query(F.data.startswith("buy_"))
async def choose_pack(call: CallbackQuery, state: FSMContext):
    key = call.data.replace("buy_", "")
    pack = CATALOG.get(key)
    await state.update_data(pack=pack)
    await call.message.edit_text(f"Вы выбрали **{pack['name']}** ({pack['rub']} ₽ / {pack['uzs']} UZS).\n\n✍️ Отправьте ваш **PUBG Player ID**:", parse_mode="Markdown")
    await state.set_state(OrderState.entering_pubg_id)
    await call.answer()

@dp.message(OrderState.entering_pubg_id)
async def get_player_id(msg: Message, state: FSMContext):
    pid = msg.text.strip()
    if not pid.isdigit() or len(pid) < 7:
        await msg.answer("❌ Введите только цифры ID:")
        return
    await state.update_data(player_id=pid)
    data = await state.get_data()
    p = data["pack"]
    await msg.answer(
        f"Пакет: **{p['name']}**\nID: `{pid}`\nК оплате: **{p['rub']} ₽** ({p['uzs']} UZS)\n\nВыберите способ оплаты:",
        reply_markup=pay_markup(),
        parse_mode="Markdown"
    )
    await state.set_state(OrderState.choosing_method)

@dp.callback_query(OrderState.choosing_method, F.data == "pay_cancel")
async def cancel_handler(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text("Заказ отменен.")
    await call.answer()

@dp.callback_query(OrderState.choosing_method, F.data.startswith("pay_"))
async def method_handler(call: CallbackQuery, state: FSMContext):
    m = call.data
    d = await state.get_data()
    p = d["pack"]
    pid = d["player_id"]
    u = call.from_user

    c = sqlite3.connect("shop.db")
    cur = c.cursor()
    cur.execute(
        "INSERT INTO orders (user_id, username, pack_name, player_id, amount_rub, amount_uzs, pay_method) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (u.id, u.username or "none", p["name"], pid, p["rub"], p["uzs"], m)
    )
    oid = cur.lastrowid
    c.commit()
    c.close()

    await state.update_data(order_id=oid, method=m)
    if m == "pay_sbp":
        txt = f"💳 **Оплата СБП / Картой РФ (Заказ #{oid})**\nСумма: **{p['rub']} ₽**\nРеквизиты:\n`{CARD_SBP_INFO}`\n\nОтправьте скриншот чека в ответ!"
    elif m == "pay_uz":
        txt = f"🇺🇿 **Оплата Click / Uzum (Заказ #{oid})**\nСумма: **{p['uzs']} UZS**\nРеквизиты:\n`{CLICK_UZUM_INFO}`\n\nОтправьте скриншот чека в ответ!"
    else:
        txt = f"🪙 **Оплата Криптовалютой (Заказ #{oid})**\nСумма: **{p['rub']} ₽ в USDT/TON**\nКошельки:\n`{CRYPTO_INFO}`\n\nОтправьте скриншот перевода в ответ!"

    await call.message.edit_text(txt, parse_mode="Markdown")
    await state.set_state(OrderState.waiting_receipt)
    await call.answer()

@dp.message(OrderState.waiting_receipt, F.photo)
async def receipt_handler(msg: Message, state: FSMContext):
    d = await state.get_data()
    oid, p, pid, u = d["order_id"], d["pack"], d["player_id"], msg.from_user
    await msg.answer(f"✅ Чек по заказу #{oid} принят! UC будут зачислены после проверки.", parse_mode="Markdown")

    adm_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Выдать UC", callback_data=f"ok_{oid}_{u.id}"),
        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"no_{oid}_{u.id}")
    ]])
    caption = f"🚨 **Заказ #{oid}**\nПокупатель: @{u.username or 'нет'} (`{u.id}`)\nПакет: **{p['name']}**\nPlayer ID: `{pid}`\nСумма: {p['rub']} ₽ ({p['uzs']} UZS)"
    await bot.send_photo(ADMIN_ID, msg.photo[-1].file_id, caption=caption, reply_markup=adm_kb, parse_mode="Markdown")
    await state.clear()

@dp.callback_query(F.data.startswith("ok_"))
async def adm_ok(call: CallbackQuery):
    _, oid, uid = call.data.split("_")
    c = sqlite3.connect("shop.db")
    c.cursor().execute("UPDATE orders SET status='done' WHERE id=?", (oid,))
    c.commit()
    c.close()
    await call.message.edit_caption(caption=call.message.caption + "\n\n✅ **ВЫПОЛНЕНО**")
    try:
        await bot.send_message(int(uid), f"🎉 Заказ #{oid} выполнен! UC зачислены на аккаунт.")
    except Exception:
        pass
    await call.answer("Выполнено!")

@dp.callback_query(F.data.startswith("no_"))
async def adm_no(call: CallbackQuery):
    _, oid, uid = call.data.split("_")
    c = sqlite3.connect("shop.db")
    c.cursor().execute("UPDATE orders SET status='rejected' WHERE id=?", (oid,))
    c.commit()
    c.close()
    await call.message.edit_caption(caption=call.message.caption + "\n\n❌ **ОТКЛОНЕНО**")
    try:
        await bot.send_message(int(uid), f"⚠️ Заказ #{oid} отклонен. Свяжитесь с поддержкой: {SUPPORT_CONTACT}")
    except Exception:
        pass
    await call.answer("Отклонено!")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
